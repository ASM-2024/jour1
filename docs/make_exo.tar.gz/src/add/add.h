#pragma once

// comment
int add(int a, int b);
