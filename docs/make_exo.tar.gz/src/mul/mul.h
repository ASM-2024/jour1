#pragma once

int mul(int a, int b);
